import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import p1 from "@/assets/p1.jpg";
import p2 from "@/assets/p2.jpg";
import p3 from "@/assets/p3.jpg";
import p4 from "@/assets/p4.jpg";
import posterA from "@/assets/poster.jpg.asset.json";
import motionA from "@/assets/motion.jpg.asset.json";
import interfaceA from "@/assets/interface.jpg.asset.json";
import kpeviA from "@/assets/kpevi.jpg.asset.json";
import ganvieA from "@/assets/ganvie.jpg.asset.json";
import daxoA from "@/assets/daxo.jpg.asset.json";
import biennaleA from "@/assets/biennale.jpg.asset.json";

const poster = posterA.url, motion = motionA.url, iface = interfaceA.url;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NEXORA — Studio créatif en mouvement · Cotonou" },
      { name: "description", content: "Communication visuelle, motion design et sites web. Un studio béninois qui pense chaque marque comme une image en mouvement." },
      { property: "og:title", content: "NEXORA — Studio créatif en mouvement" },
      { property: "og:description", content: "Communication visuelle, motion design et sites web depuis Cotonou." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Dir = "nuit" | "papier";

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".nx-reveal, .nx-fade");
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("is-in"), io.unobserve(e.target))),
      { threshold: 0.15 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function useScrollY() {
  const [y, setY] = useState(0);
  useEffect(() => {
    let raf = 0;
    const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => setY(window.scrollY)); };
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return y;
}

function useClock() {
  const [t, setT] = useState("");
  useEffect(() => {
    const f = () => setT(new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit", timeZone: "Africa/Porto-Novo" }).format(new Date()));
    f(); const id = setInterval(f, 30000); return () => clearInterval(id);
  }, []);
  return t;
}

const Mono = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <span className={`font-mono text-[11px] uppercase tracking-[0.18em] ${className}`}>{children}</span>
);

/* NEXORA letters: rise in, then breathe (width/weight); react to the pointer on desktop */
function HeroTitle({ y }: { y: number }) {
  const ref = useRef<HTMLHeadingElement>(null);
  const [pointer, setPointer] = useState(false);
  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    const h = ref.current; if (!h) return;
    const letters = Array.from(h.querySelectorAll<HTMLElement>(".nx-hero-letter"));
    let started = false;
    const move = (e: PointerEvent) => {
      if (!started) { started = true; setPointer(true); }
      letters.forEach((l) => {
        const r = l.getBoundingClientRect();
        const d = Math.hypot(e.clientX - (r.left + r.width / 2), e.clientY - (r.top + r.height / 2));
        const k = Math.max(0, 1 - d / 500);
        l.style.setProperty("--wdth", String(72 + k * 53));
        l.style.setProperty("--wght", String(400 + k * 500));
      });
    };
    window.addEventListener("pointermove", move);
    return () => window.removeEventListener("pointermove", move);
  }, []);
  return (
    <h1 ref={ref} aria-label="NEXORA"
      className={`relative z-10 flex select-none justify-between text-[22vw] uppercase leading-none tracking-[-0.02em] ${pointer ? "is-pointer" : ""}`}>
      {"NEXORA".split("").map((c, i) => (
        <span key={i} aria-hidden="true" className="block overflow-hidden">
          <span style={{ display: "inline-block", transform: `translateY(${i % 2 ? -y * 0.1 : y * 0.05}px)` }}>
            <span className={`nx-hero-letter ${i === 2 ? "text-signal" : ""}`} style={{ ["--i" as string]: i }}>{c}</span>
          </span>
        </span>
      ))}
    </h1>
  );
}

function RotatingWord() {
  const words = ["les marques", "les images", "le web", "les idées", "Cotonou"];
  const [i, setI] = useState(0);
  useEffect(() => { const id = setInterval(() => setI((v) => (v + 1) % words.length), 2200); return () => clearInterval(id); }, []);
  return (
    <span className="relative inline-block overflow-hidden align-bottom">
      <span key={i} className="nx-word inline-block text-signal">{words[i]}</span>
    </span>
  );
}

function Index() {
  const [dir, setDir] = useState<Dir>("nuit");
  useReveal();
  const y = useScrollY();
  const clock = useClock();

  return (
    <div className={`nx-root grain min-h-screen overflow-x-hidden ${dir === "nuit" ? "nx-nuit" : "nx-papier"}`}>
      {/* NAV */}
      <header className="fixed inset-x-0 top-0 z-50 flex items-center justify-between bg-background/70 px-5 py-4 backdrop-blur md:px-10">
        <a href="#" className="font-wide text-lg font-black tracking-tight">NX®</a>
        <nav className="hidden gap-8 md:flex">
          {["Studio", "Expertises", "Travaux", "Contact"].map((l) => (
            <a key={l} href={`#${l.toLowerCase()}`}><Mono>{l}</Mono></a>
          ))}
        </nav>
        <Mono><span className="text-signal">●</span> REC · {clock} WAT</Mono>
      </header>

      {/* DIRECTION SWITCH */}
      <div className="fixed bottom-4 left-1/2 z-50 flex -translate-x-1/2 items-center gap-1 rounded-full border border-border bg-background/80 p-1 backdrop-blur">
        {(["nuit", "papier"] as Dir[]).map((d) => (
          <button key={d} onClick={() => setDir(d)}
            className={`rounded-full px-4 py-2 transition-colors ${dir === d ? "bg-foreground text-background" : "text-muted-foreground"}`}>
            <Mono className="whitespace-nowrap">{d === "nuit" ? "A · Nuit" : "B · Papier"}<span className="hidden md:inline">{d === "nuit" ? " Cinéma" : " Indigo"}</span></Mono>
          </button>
        ))}
      </div>

      {/* HERO */}
      <section className="relative flex min-h-[100svh] flex-col justify-end px-5 pb-24 pt-28 md:px-10">
        <div className="pointer-events-none absolute inset-0">
          <Fragment src={poster} cap="Fig. 01 — Affiche" className="left-[5%] top-[13%] w-[30vw] max-w-[240px] md:w-[15vw]" r={-6} speed={0.25} y={y} delay="0s" />
          <Fragment src={motion} cap="Fig. 02 — Motion" className="right-[5%] top-[11%] w-[38vw] max-w-[340px] md:w-[22vw]" r={4} speed={0.45} y={y} delay="1s" />
          <div className="nx-float absolute left-[38%] top-[20%] hidden rounded-full border border-border bg-background px-4 py-2 md:block" style={{ ["--r" as string]: "8deg" }}>
            <Mono>▶ 00:12:04</Mono>
          </div>
          <svg viewBox="0 0 200 200" className="nx-spin absolute bottom-[42%] left-[8%] w-20 md:left-[46%] md:w-28">
            <defs><path id="c" d="M100,100 m-80,0 a80,80 0 1,1 160,0 a80,80 0 1,1 -160,0" /></defs>
            <text className="fill-signal font-mono text-[15px] uppercase tracking-[0.3em]">
              <textPath href="#c">Studio en mouvement · Bénin · 2026 · </textPath>
            </text>
            <circle cx="100" cy="100" r="10" className="fill-signal" />
          </svg>
        </div>

        <div className="relative">
          <div className="mb-4 flex items-end justify-between">
            <Mono className="text-muted-foreground">Édition 2026 — Vol. 01</Mono>
            <Mono className="hidden text-muted-foreground md:inline">Cotonou · 6.37°N 2.43°E</Mono>
          </div>
          <div className="relative">
            <HeroTitle y={y} />
            {/* browser fragment */}
            <figure className="absolute bottom-[-30%] left-[26%] z-20 w-[50vw] md:bottom-[-34%] md:left-[40%] md:w-[24vw]"
              style={{ transform: `translateY(${-y * 0.12}px) rotate(-1.5deg)` }}>
              <div className="nx-clip-up border border-border bg-background" style={{ ["--delay" as string]: "1.2s" }}>
                <div className="flex items-center gap-1 border-b border-border px-2 py-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-foreground/30" />
                  <span className="h-1.5 w-1.5 rounded-full bg-foreground/30" />
                  <span className="h-1.5 w-1.5 rounded-full bg-signal" />
                  <span className="ml-2 truncate font-mono text-[8px] tracking-wider text-muted-foreground md:text-[10px]">nexora.bj/concept<span className="nx-blink">|</span></span>
                </div>
                <div className="aspect-[16/10] overflow-hidden"><img src={iface} alt="Interface d'un site e-commerce éditorial" className="nx-settle h-full w-full object-cover" /></div>
              </div>
              <figcaption className="mt-1"><Mono className="text-[9px] text-muted-foreground">Fig. 03 — Interface</Mono></figcaption>
            </figure>
          </div>
          <div className="mt-24 grid gap-6 md:mt-28 md:grid-cols-12">
            <p className="font-serif text-3xl italic leading-tight md:col-span-7 md:text-5xl">
              Nous faisons bouger<br /><RotatingWord />.
            </p>
            <div className="max-w-sm md:col-span-4 md:col-start-9 md:self-end">
              <p className="text-sm text-muted-foreground">
                Communication visuelle, motion design et sites web. Un studio béninois qui pense chaque marque comme une image en mouvement.
              </p>
              <a href="#studio" className="mt-4 inline-block"><Mono>Défiler ↓</Mono></a>
            </div>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div className="overflow-hidden border-y border-border py-5">
        <div className="nx-marquee flex w-max whitespace-nowrap">
          {[0, 1].map((k) => (
            <div key={k} className="flex items-center">
              {["Communication visuelle", "Motion design", "Sites web", "Cotonou", "Bénin"].map((t) => (
                <span key={t} className="font-wide flex items-center text-5xl font-black uppercase md:text-7xl">
                  <span className="px-6">{t}</span><span className="text-signal">✺</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* STUDIO */}
      <section id="studio" className="px-5 py-28 md:px-10 md:py-40">
        <div className="flex items-baseline justify-between">
          <Mono className="text-muted-foreground">(01) — Le studio</Mono>
          <Mono className="text-muted-foreground">001 / Manifeste</Mono>
        </div>
        <p className="nx-fade font-wide mt-10 text-[8vw] font-extrabold leading-[1] tracking-[-0.03em] md:text-[4.6vw]">
          NEXORA est un studio créatif né à <span className="font-serif font-normal italic tracking-normal text-signal">Cotonou</span>. Nous dessinons des identités qui se lisent <InlineImg src={poster} /> des images qui bougent <InlineImg src={motion} /> et des sites qui se vivent <InlineImg src={iface} /> — pour les marques qui refusent de rester <span className="text-outline">immobiles</span>.
        </p>
        <div className="mt-20 grid grid-cols-2 gap-px border-t border-border md:grid-cols-4">
          {[["03", "expertises intégrées, un seul regard"], ["01", "studio, ancré au Bénin"], ["∞", "formats : print, écran, mouvement"], ["2026", "année de lancement"]].map(([n, l]) => (
            <div key={l} className="nx-fade pt-6 pr-4">
              <div className="font-wide text-5xl font-black md:text-7xl">{n}</div>
              <Mono className="mt-2 block text-muted-foreground">{l}</Mono>
            </div>
          ))}
        </div>
      </section>

      {/* EXPERTISES */}
      <section id="expertises" className="border-t border-border px-5 py-28 md:px-10 md:py-40">
        <div className="mb-6 flex items-baseline justify-between">
          <Mono className="text-muted-foreground">(02) — Expertises</Mono>
          <Mono className="text-muted-foreground">Un seul mouvement</Mono>
        </div>
        <h2 className="font-wide text-[11vw] font-black leading-[0.9] tracking-[-0.04em] md:text-[6vw]">
          Trois métiers, <span className="font-serif font-normal italic tracking-normal">un seul</span> mouvement.
        </h2>
        <p className="mb-16 mt-6 max-w-xl text-sm text-muted-foreground">
          Chaque projet traverse nos trois disciplines : l’identité donne le ton, le mouvement donne le rythme, le web donne la scène.
        </p>
        {[
          { n: "01", t: "Voir", s: "Communication visuelle", d: "Des identités qui se reconnaissent au premier regard.", img: poster, items: ["Identité de marque", "Direction artistique", "Affiches & campagnes", "Packaging", "Contenus réseaux sociaux"] },
          { n: "02", t: "Bouger", s: "Motion design", d: "Des images qui respirent, des marques qui prennent vie.", img: motion, items: ["Logos animés", "Films de marque", "Génériques & titrages", "Formats sociaux animés", "Habillage vidéo"] },
          { n: "03", t: "Habiter", s: "Sites web", d: "Des interfaces rapides, sensibles et mémorables.", img: iface, items: ["Sites vitrines", "E-commerce", "Design d’interface", "Expériences interactives", "Développement & maintenance"] },
        ].map((e) => <Expertise key={e.n} {...e} />)}
      </section>

      {/* WORKS */}
      <section id="travaux" className="px-5 pb-28 md:px-10 md:pb-40">
        <div className="mb-10 md:mb-20">
          <Mono className="text-muted-foreground">(03) — Concepts studio</Mono>
          <h2 className="font-wide mt-4 text-[13vw] font-black leading-[0.85] tracking-[-0.04em] md:text-[9vw]">
            Travaux <sup className="font-mono text-[0.2em] font-normal tracking-normal text-signal">(08)</sup>
          </h2>
          <p className="mt-6 max-w-xl text-sm text-muted-foreground">
            Les projets présentés ci-dessous sont des concepts d’exploration conçus par NEXORA pour illustrer sa démarche. Ils seront remplacés par les réalisations clients.
          </p>
        </div>
        <div className="grid gap-y-20 md:grid-cols-12 md:gap-x-8">
          <Work className="md:col-span-5" img={kpeviA.url} ratio="aspect-[4/5]" n="01" title="Kpèvi Records" tag="Identité visuelle" year="2026" d="Un label afro-électronique et un logo-cercle qui tourne comme un vinyle — décliné de la pochette au sticker." />
          <Work className="md:col-span-6 md:col-start-7 md:mt-48" img={ganvieA.url} ratio="aspect-[4/5]" n="02" title="Ganvié l’heure bleue" tag="Motion design — Générique" year="2026" d="Générique d’ouverture pour un festival de cinéma imaginaire : 45 secondes de lumière sur le lac Nokoué." />
          <Work className="md:col-span-8 md:col-start-3" img={daxoA.url} ratio="aspect-[16/10]" n="03" title="Atelier Dàxó" tag="Site e-commerce" year="2026" d="Une boutique en ligne où chaque tissu se déroule au défilement, pensée d’abord pour le mobile." />
          <Work className="md:col-span-7" img={biennaleA.url} ratio="aspect-[16/11]" n="04" title="Biennale Cotonou Design" tag="Campagne d’affichage" year="2026" d="Des lettres qui se déforment sous le soleil : une campagne pensée pour la rue, déclinée en motion." />
          <Work className="md:col-span-4 md:col-start-9 md:mt-32" img={p1} ratio="aspect-[4/5]" n="05" title="Sons d'Ancêtres" tag="Affiche festival" year="2026" />
          <Work className="md:col-span-5" img={p4} ratio="aspect-[4/5]" n="06" title="Kora Café" tag="Identité & packaging" year="2026" />
          <Work className="md:col-span-6 md:col-start-7 md:mt-40" img={p2} ratio="aspect-[16/10]" n="07" title="Flux" tag="Film de marque, motion" year="2025" />
          <Work className="md:col-span-8 md:col-start-2" img={p3} ratio="aspect-[16/11]" n="08" title="Éliore" tag="Site e-commerce" year="2025" />
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="relative overflow-hidden bg-foreground px-5 pb-32 pt-24 text-background md:px-10">
        <Mono className="opacity-60">(04) — Contact</Mono>
        <h2 className="font-wide mt-8 text-[13vw] font-black leading-[0.85] tracking-[-0.05em] md:text-[9vw]">
          Un projet<span className="text-signal">?</span><br />
          <span className="font-serif font-normal italic tracking-normal">Mettons-le</span> en mouvement.
        </h2>
        <div className="mt-12 flex flex-wrap items-center justify-between gap-6 border-t border-background/20 pt-8">
          <a href="mailto:bonjour@nexora.bj" className="font-serif text-3xl italic transition-colors hover:text-signal md:text-5xl">bonjour@nexora.bj ↗</a>
          <a href="mailto:bonjour@nexora.bj?subject=Nouveau%20projet" className="rounded-full bg-signal px-8 py-5 text-foreground transition-transform hover:scale-105">
            <Mono className="font-semibold">Démarrer un projet →</Mono>
          </a>
        </div>
        <div className="mt-20 grid gap-10 border-t border-background/20 pt-8 md:grid-cols-3">
          <div>
            <Mono className="opacity-60">Studio</Mono>
            <p className="mt-3 font-serif text-2xl italic">Cotonou, Bénin</p>
            <Mono className="mt-1 block opacity-60">{clock} — heure locale</Mono>
          </div>
          <div>
            <Mono className="opacity-60">Nouveaux projets</Mono>
            <p className="mt-3 font-serif text-2xl italic">Réponse sous 48 h</p>
            <Mono className="mt-1 block opacity-60">Français · English</Mono>
          </div>
          <div>
            <Mono className="opacity-60">Suivre le mouvement</Mono>
            <ul className="mt-3 space-y-1">
              {["Instagram", "Behance", "LinkedIn", "WhatsApp"].map((s) => (
                <li key={s}><a href="#" className="font-serif text-2xl italic transition-colors hover:text-signal">{s} ↗</a></li>
              ))}
            </ul>
          </div>
        </div>
        <footer className="mt-24">
          <div className="font-wide select-none text-[22vw] font-black leading-[0.8] tracking-[-0.05em] opacity-10">NEXORA</div>
          <div className="mt-6 flex flex-wrap justify-between gap-4 opacity-60">
            <Mono>© 2026 NEXORA Studio</Mono>
            <Mono>Agence créative & digitale · Cotonou</Mono>
            <a href="#"><Mono>Retour en haut ↑</Mono></a>
          </div>
        </footer>
      </section>
    </div>
  );
}

function InlineImg({ src }: { src: string }) {
  return <img src={src} alt="" className="mx-1 inline-block h-[0.8em] w-[1.6em] rounded-full object-cover align-baseline" />;
}

function Fragment({ src, cap, className, r, speed, y, delay }: { src: string; cap: string; className: string; r: number; speed: number; y: number; delay: string }) {
  return (
    <div className={`absolute ${className}`} style={{ transform: `translateY(${-y * speed}px)` }}>
      <div className="nx-float" style={{ ["--r" as string]: `${r}deg`, rotate: `${r}deg`, animationDelay: delay }}>
        <div className="overflow-hidden"><img src={src} alt="" className="block w-full opacity-90" /></div>
        <Mono className="mt-1 block text-[9px] text-muted-foreground">{cap}</Mono>
      </div>
    </div>
  );
}

function Expertise({ n, t, s, d, img, items }: { n: string; t: string; s: string; d: string; img: string; items: string[] }) {
  const [hover, setHover] = useState(false);
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      className="nx-fade group relative grid grid-cols-12 items-start gap-4 border-t border-border py-8 md:py-12">
      <Mono className="col-span-2 pt-3 text-muted-foreground md:col-span-1">{n}</Mono>
      <h3 className="font-wide col-span-10 text-[16vw] font-black leading-[0.85] tracking-[-0.04em] transition-transform duration-700 group-hover:translate-x-4 md:col-span-6 md:text-[8vw]">
        {t}<span className="text-signal">.</span>
      </h3>
      <div className="col-span-12 md:col-span-4 md:col-start-9">
        <p className="font-serif text-2xl italic">{s}</p>
        <p className="mt-2 text-sm text-muted-foreground">{d}</p>
        <ul className="mt-5 flex flex-wrap gap-2">
          {items.map((it) => (
            <li key={it} className="rounded-full border border-border px-3 py-1">
              <Mono className="text-[10px]"><span className="text-signal">/</span>{it}</Mono>
            </li>
          ))}
        </ul>
      </div>
      <img src={img} alt="" loading="lazy"
        className="pointer-events-none absolute right-[36%] top-1/2 hidden w-56 -translate-y-1/2 object-cover transition-all duration-700 md:block"
        style={{ clipPath: hover ? "inset(0 0 0 0)" : "inset(50% 50% 50% 50%)", rotate: hover ? "-4deg" : "0deg" }} />
    </div>
  );
}

function Work({ className, img, ratio, n, title, tag, year, d }: { className: string; img: string; ratio: string; n: string; title: string; tag: string; year: string; d?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [off, setOff] = useState(0);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const io = new IntersectionObserver(([e]) => e?.isIntersecting && setInView(true), { threshold: 0.1 });
    if (ref.current?.parentElement) io.observe(ref.current.parentElement);
    return () => io.disconnect();
  }, []);
  useEffect(() => {
    const on = () => {
      const r = ref.current?.getBoundingClientRect();
      if (r) setOff((r.top + r.height / 2 - window.innerHeight / 2) * -0.08);
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <a href="#contact" className={`group block ${className}`}>
      <div ref={ref} className={`nx-reveal relative overflow-hidden ${inView ? "is-in" : ""} ${ratio}`}>
        <img src={img} alt={title} loading="lazy" className="absolute inset-0 h-[115%] w-full object-cover transition-transform duration-[1.2s] group-hover:scale-105"
          style={{ top: "-7.5%", translate: `0 ${off}px` }} />
        <span className="absolute left-4 top-4 rounded-full bg-background px-3 py-1"><Mono>{n} / {year}</Mono></span>
        <span className="absolute right-4 top-4 rounded-full bg-signal px-3 py-1 text-foreground"><Mono>Concept</Mono></span>
      </div>
      <div className="mt-4 border-b border-border pb-4">
        <div className="flex items-baseline justify-between gap-4">
          <h3 className="font-wide text-3xl font-black tracking-tight md:text-5xl">
            {title}<span className="inline-block text-signal transition-transform duration-500 group-hover:-translate-y-2 group-hover:translate-x-2">↗</span>
          </h3>
          <Mono className="text-right text-muted-foreground">{tag}</Mono>
        </div>
        {d && <p className="mt-3 max-w-lg text-sm text-muted-foreground">{d}</p>}
      </div>
    </a>
  );
}
